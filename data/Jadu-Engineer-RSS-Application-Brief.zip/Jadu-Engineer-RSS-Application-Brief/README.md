# Jadu Engineer RSS Application

This is a Laravel application. The architecture is [MVC](https://en.wikipedia.org/wiki/Model%E2%80%93view%E2%80%93controller) 
and the technique used was [TDD](https://en.wikipedia.org/wiki/Test-driven_development). 

## Table of Contents
- [Installation](#installation)
- [Extra Features](#extra-features)
- [Structure](#structure)
    - [Model](#model)
    - [View](#view)
    - [Controller](#controller)
    - [Other important parts of the project](#other-important-parts-of-the-project)
        - [Routing](#routing)
        - [Policies](#policies)
        - [Services](#services)
        - [Factories](#factories)
        - [Migration](#migration)
        - [Seeds](#seeds)
        - [Browser tests](#browser-tests)
        - [Unit tests](#unit-tests)
        - [Feature tests](#feature-tests)
- [Users](#users)
- [Security](#security)
- [Testing](#testing)
- [Time](#time)
- [Future Updates](#future-updates)

## Installation

For installation instructions, see [Instructions](instructions.md#application-installation).

## Extra Features

The extra features added are:
- Users can edit/delete an rss feed only when they are they ones created it
- When showing a specific rss feed, you can also see the title and url of the 10 more recent articles 

## Structure

An MVC architecture has been used. 

### Model

The only Model created was [app/RssFeed.php](app/RssFeed.php)

### View

All view files are in the folder [resources/views/rss_feeds](resources/views/rss_feeds)

### Controller

All Controllers are in the folder [app/Http/Controllers](app/Http/Controllers). The only Controller that was implemented was [RssFeedsController](app/Http/Controllers/RssFeedsController.php)

### Other important parts of the project

#### Routing

[routes/web.php](routes/web.php)

#### Policies

[app/Policies/RssFeedPolicy.php](app/Policies/RssFeedPolicy.php) determines that only an rss owner is allowed to edit/delete the entry. 

#### Services

[app/Services/FeedReader.php](app/Services/FeedReader.php) is a service responsible for reading an RSS feed and translating it into an array of [FeedArticles](app/FeedArticle.php). 

A [FeedArticle](app/FeedArticle.php) is an Object with the title and url of an RSS item.  

#### Factories

[RssFeedFactory](database/factories/RssFeedFactory.php) creates a random rss feed

#### Migration

[2019_04_30_181311_create_rss_Feeds_table.php](database/migrations/2019_04_30_181311_create_rss_Feeds_table.php) creates the table where rss entries are stored

#### Seeds

[DatabaseSeeder.php](database/seeds/DatabaseSeeder.php) seeds the application with some random data and some specific for testing purposes

#### Browser tests

The php files in the folder [tests/Browser](tests/Browser).  

All browser tests help us maintain that each page shows the right content, and all click interactions work correctly. 

#### Unit tests

They are in folder [tests/Unit](tests/Unit)

- [RssReaderTest.php](tests/Unit/RssReaderTest.php) This tests the [app/Services/FeedReader.php](app/Services/FeedReader.php) and confirms that the XML is parsed correctly.
To do that, an rss of an [owned page](https://cretan.dev) is used. The test of function `testFeedReader` is valid until May 6th 2019. After that it should be updated accordingly. 
It tests agains XML injection and the Billion-Laughs-Attack. The files used for some examples are in folder [tests/data](tests/data)
- [FeedReadingTest.php](tests/Feature/FeedReadingTest.php) Mocks the [app/Services/FeedReader.php](app/Services/FeedReader.php) 
and tests the function [show](app/Http/Controllers/RssFeedsController.php#L80) that shows the most recent titles (and url) of the specific rss feed. 

#### Feature tests

They are in folder [tests/Feature](tests/Feature)

- [RssFeedTest.php](tests/Feature/RssFeedTest.php) Tests that all routes show the appropriate page (depending on the current user, if any).
- [FallbackRouteTest.php](tests/Feature/FallbackRouteTest.php) Tests the fallback route.  


## Users

The Users model is available by default in a Laravel Application. 
The Users' authentication proceedure (including login, logout, register, forget password with all necessary views, controller, migration, factory) was automatically created with the command `php artisan make:auth`

## Security

The application has been tested against 
- [Broken Authentication](https://www.owasp.org/index.php/Top_10-2017_A2-Broken_Authentication) in [RssFeedTest](tests/Feature/RssFeedTest.php)
- [XML External Entities (XXE) Attack](https://www.owasp.org/index.php/XML_External_Entity_(XXE)_Processing) 
    in [XmlRssParserTest](tests/Unit/XmlRssParserTest.php)
- [SQL injection](https://www.owasp.org/index.php/SQL_Injection) and [Cross-site Scripting (XSS)](https://www.owasp.org/index.php/Cross-site_Scripting_(XSS) 
    in [SqlInjectionTest](tests/Feature/SqlInjectionTest.php)


## Testing

[Here](instructions.md#running-tests) you can see how to run all tests.

## Time

[Here](time.md) you can see a review of how the time broke down while developing this application

## Future updates

- When showing a specific rss feed, add the description of each article
- Users that don't own a specific rss feed can't click on the link to edit it. 
    Even though they currently can click the link, they still can't edit it, but we need to deactivate the link altogether. 
 