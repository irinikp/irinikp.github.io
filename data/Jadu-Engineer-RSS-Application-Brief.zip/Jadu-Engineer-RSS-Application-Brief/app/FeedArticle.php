<?php


namespace App;


/**
 * Class FeedArticle
 * @package App
 */
class FeedArticle
{
    /**
     * @var string
     */
    protected $title;
    /**
     * @var string
     */
    protected $url;

    /**
     * FeedArticle constructor.
     *
     * @param $title
     * @param $url
     */
    public function __construct($title, $url)
    {
        $this->title = $title;
        $this->url   = $url;
    }

    /**
     * @return string
     */
    public function getTitle(): string
    {
        return $this->title;
    }

    /**
     * @param string $title
     */
    public function setTitle(string $title): void
    {
        $this->title = $title;
    }

    /**
     * @return string
     */
    public function getUrl(): string
    {
        return $this->url;
    }

    /**
     * @param string $url
     */
    public function setUrl(string $url): void
    {
        $this->url = $url;
    }

}