<?php

namespace App\Http\Controllers;

use App\RssFeed;
use App\Services\FeedReader;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

/**
 * Class RssFeedsController
 * @package App\Http\Controllers
 */
class RssFeedsController extends Controller
{
    protected $service;

    /**
     * RssFeedsController constructor.
     *
     * @param FeedReader $service
     */
    public function __construct(FeedReader $service)
    {
        $this->service = $service;
        $this->middleware('auth')->except(['index', 'show']);
    }

    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        $rss_feeds = RssFeed::latest()->get();
        return view('rss_feeds.index', compact('rss_feeds'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        return view('rss_feeds.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'url' => 'required|url',
        ]);

        $rss_feed = RssFeed::create([
            'url'     => strip_tags($request->get('url')),
            'user_id' => Auth::id()
        ]);

        return redirect('/rss_feeds/' . $rss_feed->id);
    }

    /**
     * Display the specified resource.
     *
     * @param RssFeed $rss_feed
     *
     * @return Response
     */
    public function show(RssFeed $rss_feed)
    {
        $rss_contents = $this->service->read($rss_feed->url);
        $rss_limit = FeedReader::RECENT_LIMIT;
        return view('rss_feeds.show', compact('rss_feed', 'rss_contents', 'rss_limit'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param RssFeed $rss_feed
     *
     * @return Response
     */
    public function edit(RssFeed $rss_feed)
    {
        return view('rss_feeds.edit', compact('rss_feed'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param RssFeed $rss_feed
     *
     * @return Response
     * @throws AuthorizationException
     */
    public function update(Request $request, RssFeed $rss_feed)
    {
        $this->authorize('update', $rss_feed);
        $request->validate([
            'url' => 'required|url',
        ]);

        $rss_feed->url= strip_tags($request->get('url'));

        $rss_feed->save();

        return redirect('/rss_feeds/' . $rss_feed->id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param RssFeed $rss_feed
     *
     * @return Response
     * @throws AuthorizationException
     */
    public function destroy(RssFeed $rss_feed)
    {
        $this->authorize('update', $rss_feed);
        $rss_feed->delete();

        return redirect("/rss_feeds");
    }
}
