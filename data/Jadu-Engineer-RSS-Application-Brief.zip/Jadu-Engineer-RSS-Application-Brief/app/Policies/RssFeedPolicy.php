<?php

namespace App\Policies;

use App\RssFeed;
use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class RssFeedPolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view the rss feed.
     *
     * @param \App\User    $user
     * @param \App\RssFeed $rssFeed
     *
     * @return mixed
     */
    public function view(User $user, RssFeed $rssFeed)
    {
        //
    }

    /**
     * Determine whether the user can create rss feeds.
     *
     * @param \App\User $user
     *
     * @return mixed
     */
    public function create(User $user)
    {
        //
    }

    /**
     * Determine whether the user can update the rss feed.
     *
     * @param \App\User    $user
     * @param \App\RssFeed $rssFeed
     *
     * @return mixed
     */
    public function update(User $user, RssFeed $rssFeed)
    {
        return $rssFeed->user_id == $user->id;
    }

    /**
     * Determine whether the user can delete the rss feed.
     *
     * @param \App\User    $user
     * @param \App\RssFeed $rssFeed
     *
     * @return mixed
     */
    public function delete(User $user, RssFeed $rssFeed)
    {
        return $rssFeed->user_id == $user->id;
    }

    /**
     * Determine whether the user can restore the rss feed.
     *
     * @param \App\User    $user
     * @param \App\RssFeed $rssFeed
     *
     * @return mixed
     */
    public function restore(User $user, RssFeed $rssFeed)
    {
        //
    }

    /**
     * Determine whether the user can permanently delete the rss feed.
     *
     * @param \App\User    $user
     * @param \App\RssFeed $rssFeed
     *
     * @return mixed
     */
    public function forceDelete(User $user, RssFeed $rssFeed)
    {
        //
    }
}
