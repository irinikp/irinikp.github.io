<?php


namespace App\Services;


use App\FeedArticle;
use DOMDocument;

/**
 * Class FeedReader
 * @package App\Services
 */
class FeedReader
{
    public const RECENT_LIMIT = 10;

    protected $xml_parser;

    public function __construct(XmlRssParser $xml_parser)
    {
        $this->xml_parser = $xml_parser;
    }

    /**
     * @param string $url
     *
     * @return array<FeedArticle>|null
     */
    public function read(string $url): ?array
    {
        $rss = $this->loadRss($url);
        if ($rss) {
            return $this->xml_parser->separateFeedIntoArticles($rss);
        } else {
            return null;
        }
    }

    /**
     * @param string $url
     *
     * @return DOMDocument|null
     */
    protected function loadRss(string $url): ?DOMDocument
    {
        $rss    = new DOMDocument();
        try {
            $loaded = $rss->load($url);
            return $loaded ? $rss : null;
        } catch (\ErrorException $e) {
            return null;
        }
    }

}