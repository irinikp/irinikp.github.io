<?php


namespace App\Services;


use App\FeedArticle;
use DOMDocument;
use DOMElement;

/**
 * Class XmlRssParser
 * @package App\Services
 */
class XmlRssParser
{
    /**
     * @param DOMDocument $rss
     *
     * @return array<FeedArticle>
     */
    public function separateFeedIntoArticles(DOMDocument $rss): array
    {
        $feed = [];
        if (!$this->filterOutDangerousXml($rss)) {
            return $feed;
        }
        foreach ($rss->getElementsByTagName('item') as $node) {
            $item  = new FeedArticle($this->cleanInputString($this->getNodeValue($node, 'title')), $this->cleanInputString($this->getNodeValue($node, 'link')));
            array_push($feed, $item);
        }

        return $feed;
    }

    /**
     * @param DOMElement $node
     * @param string     $elt_name
     *
     * @return string
     */
    protected function getNodeValue(DOMElement $node, string $elt_name): string
    {
        $value     = '';
        $value_elt = $node->getElementsByTagName($elt_name);
        $item      = $value_elt->item(0);
        if ($item) {
            $value = $item->nodeValue;
        }
        return $value;

    }

    /**
     * @param DOMDocument $rss
     *
     * @return bool
     */
    protected function filterOutDangerousXml(DOMDocument $rss): bool
    {
        $xml = $rss->saveHTML();
        if (!$xml) {
            return false;
        } else {
            if (strpos($xml, '!DOCTYPE') !== false) {
                return false;
            }
            if (strpos($xml, '!ENTITY') !== false) {
                return false;
            }
        }
        return true;
    }

    /**
     * @param string $input
     *
     * @return string
     */
    protected function cleanInputString(string $input): string
    {
        $input = strip_tags(htmlspecialchars($input));
        $input = str_replace('&amp;', '&', $input);
        return $input;
    }

}