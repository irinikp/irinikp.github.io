<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $this->seedSpecificUser(1);
        $this->seedSpecificRss(1);
        factory('App\RssFeed', 20)->create();
    }

    protected function seedSpecificUser($user_id)
    {
        DB::table('users')->insert([
            'id'       => $user_id,
            'name'     => 'irini',
            'email'    => 'irinikp@gmail.com',
            'password' => bcrypt('102938'),
        ]);
    }

    protected function seedSpecificRss($user_id)
    {
        DB::table('rss_feeds')->insert([
            'user_id' => $user_id,
            'url'     => 'http://www.php.net/news.rss'
        ]);
        DB::table('rss_feeds')->insert([
            'user_id' => $user_id,
            'url'     => 'http://slashdot.org/rss/slashdot.rss'
        ]);
        DB::table('rss_feeds')->insert([
            'user_id' => $user_id,
            'url'     => 'http://newsrss.bbc.co.uk/rss/newsonline_uk_edition/front_page/rss.xml'
        ]);
        DB::table('rss_feeds')->insert([
            'user_id' => $user_id,
            'url'     => 'https://cretan.dev/feed.xml'
        ]);
    }
}
