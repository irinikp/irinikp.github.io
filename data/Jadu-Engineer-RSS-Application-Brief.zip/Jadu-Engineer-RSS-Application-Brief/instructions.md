# Instructions

## Application Installation

#### 1. Database Creation
1. Enter into mysql from your consolle, by typing:
    ```zsh
    mysql -u root -p
    ``` 
2. Type the MySQL root password, and then press Enter
3. Create a database (put your name of choice in place of `my_db_name`)
    ```mysql
    CREATE DATABASE my_db_name;
    ```

#### 2. Composer
Download composer [https://getcomposer.org/download/](https://getcomposer.org/download/)

#### 3. Download the application
```zsh
git clone https://github.com/irinikp/Jadu-Engineer-RSS-Application-Brief.git
```

#### 3. Create .env
1. Rename `.env.example` file to `.env`
2. Replace the following lines
    ```text
    DB_DATABASE=homestead
    DB_USERNAME=homestead
    DB_PASSWORD=secret
    ```
    with 
    ```text
    DB_DATABASE=my_db_name
    DB_USERNAME=root
    DB_PASSWORD=root_password
    ```
    where `my_db_name` is the name of the database, `root` is the user and `root_password` is the password of the root user

#### 4. Composer
1. Cd into the project folder from the console
2. Run `composer install`

#### 5. Setup remaining application components
From the console: 
1. Run `php artisan key:generate`
2. Run `php artisan migrate`
3. Run `php artisan db:seed`

#### 6. Run
1. Write in the console `php artisan serve` and open the url shown (it should be [http://127.0.0.1:8000](http://127.0.0.1:8000))
2. If the url shown is different than the value of `APP_URL` of file `.env`, make sure to update it accordingly, in order for the browser's tests to succeed.

## Login
You can either register by clicking 'REGISTER' on the top right of the screen, or use the credentials below:
```text
username: irinikp@gmail.com
password: 102938
```

User *irini* owns the feeds below (therefore allowed to edit/delete them):
- http://www.php.net/news.rss
- http://slashdot.org/rss/slashdot.rss
- http://newsrss.bbc.co.uk/rss/newsonline_uk_edition/front_page/rss.xml
- https://cretan.dev/feed.xml 

## Running Tests

__Attention__ Do not run all tests at once, because the dusk tests (Browser tests) will fail. You should run them separately, based on the instructions bellow

#### Unit Tests
```zsh
phpunit tests --filter Unit
```

#### Feature Tests
```zsh
phpunit tests --filter Feature
```

#### Browser Tests
1. Execute 
    ```zsh
    php artisan serve
    ```
2. Execute
    ```zsh
    phpunit artisan dusk
    ```
3. Make sure to run `php artisan migrate` and `php artisan db:seed` after executing the Browser Tests