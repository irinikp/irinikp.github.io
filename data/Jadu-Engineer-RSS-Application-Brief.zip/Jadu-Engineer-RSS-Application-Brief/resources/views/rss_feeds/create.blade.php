@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><strong>Add a new RSS Feed</strong></div>

                    <div class="card-body">
                        <form method="POST" action="/rss_feeds/create">
                            {{csrf_field()}}
                            <div class="form-group">
                                <input type="text" class="form-control" name="url" id="url"
                                       placeholder="Enter the rss url">
                            </div>
                            <button class="btn btn-primary" type="Submit">Add RSS Feed</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @if(count($errors))
        <div class="alert alert-danger">
            @foreach($errors->all() as $error)
                <li>
                    {{$error}}
                </li>
            @endforeach
        </div>
    @endif
@endsection