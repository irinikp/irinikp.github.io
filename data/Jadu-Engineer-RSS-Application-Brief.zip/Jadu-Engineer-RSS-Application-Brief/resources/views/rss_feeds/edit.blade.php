@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><strong>Update RSS Feed</strong></div>

                    <div class="card-body">
                        <form method="POST" action="/rss_feeds/{{$rss_feed->id}}">
                            {{csrf_field()}}
                            {{method_field('PUT')}}
                            <div class="form-group">
                                <input type="text" class="form-control" name="url" id="url"
                                       placeholder="Enter the RSS url"
                                       value="{{$rss_feed->url}}">
                            </div>
                            <div class="card-footer">
                                @can('update', $rss_feed)
                                    <button class="btn btn-warning" type="submit">Edit RSS Feed</button>
                                @endcan
                            </div>
                        </form>
                    </div>
                </div>

                @if(count($errors))
                    <div class="alert alert-danger">
                        @foreach($errors->all() as $error)
                            <li>
                                {{$error}}
                            </li>
                        @endforeach
                    </div>
                @endif
            </div>
        </div>
    </div>
@endsection