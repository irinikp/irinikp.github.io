@extends('layouts.app')

@section('content')
    <div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="page-header">
                <h2>All Rss Feed</h2>
            </div>
            @foreach($rss_feeds as $rss)
                <div class="card">
                    <div class="card-header"><a href="/rss_feeds/{{$rss->id}}">{{$rss->url}}</a></div>
                </div>
            @endforeach
        </div>
    </div>
</div>
@endsection