@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="page-header">
                    <h2>RSS Feed Details</h2>
                </div>
                <div class="card">
                    <div class="card-header"><a href="/rss_feeds/{{$rss_feed->id}}/edit">{{$rss_feed->url}}</a>
                        @can('delete', $rss_feed)
                            <form style="float:right" method="POST" action="/rss_feeds/{{$rss_feed->id}}">
                                {{csrf_field()}}
                                {{method_field('DELETE')}}
                                <button class="btn btn-danger" type="submit">Delete</button>
                            </form>
                        @endcan
                    </div>
                    <div class="card-body">
                        <ul>
                            @if($rss_contents)
                                @php ($i = 0)
                                @foreach($rss_contents as $article)
                                    <li><a href="{{$article->getUrl()}}" title="{{$article->getTitle()}}"
                                           target="blank">{{$article->getTitle()}}</a></li>
                                    @if( ++$i>$rss_limit)
                                        @break
                                    @endif
                                @endforeach
                            @endif
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
