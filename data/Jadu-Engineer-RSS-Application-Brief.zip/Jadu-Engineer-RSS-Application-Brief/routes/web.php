<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('/rss_feeds', 'RssFeedsController@index');
Route::post('/rss_feeds/create', 'RssFeedsController@store');
Route::get('/rss_feeds/create', 'RssFeedsController@create');
Route::get('/rss_feeds/{rss_feed}', 'RssFeedsController@show');
Route::put('/rss_feeds/{rss_feed}', 'RssFeedsController@update');
Route::get('/rss_feeds/{rss_feed}/edit', 'RssFeedsController@edit');
Route::delete('/rss_feeds/{rss_feed}', 'RssFeedsController@destroy');

Route::fallback(function () {
    return view('fallback');
});