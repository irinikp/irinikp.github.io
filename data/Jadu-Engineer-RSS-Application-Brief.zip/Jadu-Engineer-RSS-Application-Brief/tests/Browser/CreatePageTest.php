<?php

namespace Tests\Browser;

use App\User;
use Illuminate\Foundation\Testing\DatabaseMigrations;
use Laravel\Dusk\Browser;
use Tests\DuskTestCase;

class CreatePageTest extends DuskTestCase
{
    use DatabaseMigrations;

    public function testCanNotCreateWithoutLogin()
    {
        $this->browse(function (Browser $browser) {
            $browser->visit('/rss_feeds/create')
                ->assertDontSee('Add a new RSS Feed')
                ->assertDontSee('Add RSS Feed')
                ->assertPathIs('/login');
        });
    }

    public function testCanViewCreatePageAfterLogin()
    {
        $this->browse(function (Browser $browser) {
            $user     = factory(User::class)->create();
            $browser->loginAs($user)
                ->visit('/rss_feeds/create')
                ->assertSee('Add a new RSS Feed')
                ->assertSee('Add RSS Feed');
        });
    }
}
