<?php

namespace Tests\Browser;

use App\RssFeed;
use App\User;
use Illuminate\Foundation\Testing\DatabaseMigrations;
use Illuminate\Support\Facades\Auth;
use Laravel\Dusk\Browser;
use Tests\DuskTestCase;

class EditPageTest extends DuskTestCase
{
    use DatabaseMigrations;

    public function testCanNotEditWithoutLogin()
    {
        $this->browse(function (Browser $browser) {
            $rss_feed = factory(RssFeed::class)->create(['url' => self::COMMON_RSS_URL]);
            $browser->visit('/rss_feeds/' . $rss_feed->id . '/edit')
                ->assertDontSee('Update RSS Feed')
                ->assertDontSee($rss_feed->url)
                ->assertDontSee('Edit RSS Feed')
                ->assertPathIs('/login');
        });
    }

    public function testCanViewEditPageAfterLogin()
    {
        $this->browse(function (Browser $browser) {
            $rss_feed = factory(RssFeed::class)->create(['url' => self::COMMON_RSS_URL]);
            $user     = factory(User::class)->create();
            $browser->loginAs($user)
                ->visit('/rss_feeds/' . $rss_feed->id . '/edit')
                ->assertSee('Update RSS Feed')
                ->assertDontSee('Edit RSS Feed');
        });
    }

    public function testCanEditPageAfterLogin()
    {
        $this->browse(function (Browser $browser) {
            $rss_feed = factory(RssFeed::class)->create(['url' => self::COMMON_RSS_URL]);
            $browser->loginAs(User::find($rss_feed->user_id))
                ->visit('/rss_feeds/' . $rss_feed->id . '/edit')
                ->assertSee('Update RSS Feed')
                ->assertSee('Edit RSS Feed');
        });
    }

    public function testSeeIndexLink()
    {
        $this->browse(function (Browser $browser) {
            $rss_feed = factory(RssFeed::class)->create(['url' => self::COMMON_RSS_URL]);
            $user     = factory(User::class)->create();
            $browser->loginAs($user)
                ->visit('/rss_feeds/' . $rss_feed->id . '/edit')
                ->assertSee('RSS Feeds')
                ->clickLink('RSS Feeds')
                ->assertPathIs('/rss_feeds');
        });
    }
}
