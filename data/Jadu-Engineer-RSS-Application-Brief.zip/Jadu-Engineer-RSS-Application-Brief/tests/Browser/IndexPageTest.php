<?php

namespace Tests\Browser;

use App\RssFeed;
use Illuminate\Foundation\Testing\DatabaseMigrations;
use Laravel\Dusk\Browser;
use Tests\DuskTestCase;

class IndexPageTest extends DuskTestCase
{
    use DatabaseMigrations;

    public function testView()
    {
        $this->browse(function (Browser $browser) {
            $rss_feed = factory(RssFeed::class)->create(['url' => self::COMMON_RSS_URL]);
            $browser->visit('/rss_feeds')
                ->assertSee('All Rss Feed')
                ->assertSeeLink($rss_feed->url);
        });
    }

    public function testClickRssLink()
    {
        $this->browse(function (Browser $browser) {
            $rss_feed = factory(RssFeed::class)->create(['url' => self::COMMON_RSS_URL]);
            $browser->visit('/rss_feeds')
                ->clickLink($rss_feed->url)
                ->assertPathIs('/rss_feeds/' . $rss_feed->id);
        });
    }

}
