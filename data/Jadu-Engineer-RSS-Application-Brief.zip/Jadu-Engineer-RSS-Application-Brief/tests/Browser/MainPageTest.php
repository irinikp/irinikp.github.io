<?php

namespace Tests\Browser;

use Laravel\Dusk\Browser;
use Tests\DuskTestCase;

class MainPageTest extends DuskTestCase
{
    public function testBasic()
    {
        $this->browse(function (Browser $browser) {
            $browser->visit('/')
                ->assertSee('Rss Feed')
                ->assertSeeLink('View')
                ->assertSeeLink('Login')
                ->assertSeeLink('Register');
        });
    }

    public function testClickRss()
    {
        $this->browse(function (Browser $browser) {
            $browser->visit('/')
                ->clickLink('View')
                ->assertPathIs('/rss_feeds');
        });

    }

    public function testClickLogin()
    {
        $this->browse(function (Browser $browser) {
            $browser->visit('/')
                ->clickLink('Login')
                ->assertPathIs('/login');
        });

    }

    public function testClickRegister()
    {
        $this->browse(function (Browser $browser) {
            $browser->visit('/')
                ->clickLink('Register')
                ->assertPathIs('/register');
        });

    }

}
