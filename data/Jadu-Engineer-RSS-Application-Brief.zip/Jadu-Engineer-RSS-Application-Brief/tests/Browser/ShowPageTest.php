<?php

namespace Tests\Browser;

use App\RssFeed;
use App\User;
use Illuminate\Foundation\Testing\DatabaseMigrations;
use Laravel\Dusk\Browser;
use Tests\DuskTestCase;

class ShowPageTest extends DuskTestCase
{
    use DatabaseMigrations;

    public function testAnyoneCanSeeRss()
    {
        $this->browse(function (Browser $browser) {
            $rss_feed = factory(RssFeed::class)->create(['url' => self::COMMON_RSS_URL]);
            $browser->visit('/rss_feeds/' . $rss_feed->id)
                ->assertSeeLink($rss_feed->url)
                ->assertDontSee('Delete');
        });
    }

    public function testUserCanNotDeleteNotOwnedRss()
    {
        $this->browse(function (Browser $browser) {
            $rss_feed = factory(RssFeed::class)->create(['url' => self::COMMON_RSS_URL]);
            $user     = factory(User::class)->create();
            $browser->loginAs($user)
                ->visit('/rss_feeds/' . $rss_feed->id)
                ->assertSeeLink($rss_feed->url)
                ->assertDontSee('Delete');
        });
    }

    public function testUserCanDeleteOwnedRss()
    {
        $this->browse(function (Browser $browser) {
            $rss_feed = factory(RssFeed::class)->create(['url' => self::COMMON_RSS_URL]);
            $browser->loginAs(User::find($rss_feed->user_id))
                ->visit('/rss_feeds/' . $rss_feed->id)
                ->assertSee('Delete');
        });
    }

}