<?php
namespace Tests\Feature;
use Tests\TestCase;
/**
 * Class FallbackRouteTest
 * @package Tests\Feature
 */
class FallbackRouteTest extends TestCase
{
    public function test_missing_api_route_should_return_404()
    {
        $this->get('/missing-route')
            ->assertSeeText('This page does not exist');
    }
}