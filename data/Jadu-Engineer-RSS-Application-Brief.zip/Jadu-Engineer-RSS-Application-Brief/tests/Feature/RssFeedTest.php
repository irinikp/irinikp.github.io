<?php

namespace Tests\Feature;

use App\RssFeed;
use App\User;
use Illuminate\Foundation\Testing\DatabaseMigrations;
use Illuminate\Support\Facades\Auth;
use Tests\TestCase;

class RssFeedTest extends TestCase
{
    use DatabaseMigrations;

    public function testReadAllRss()
    {
        $rss_feed = factory(RssFeed::class)->create();
        $response = $this->get('/rss_feeds');
        $response->assertSee($rss_feed->url);

    }

    public function testReadASingleRss()
    {
        $rss_feed = factory(RssFeed::class)->create();
        $response = $this->get('/rss_feeds/' . $rss_feed->id);
        $response->assertSee($rss_feed->url);
        $response->assertSee($rss_feed->user_id);
    }

    public function testAuthenticatedUserCanCreateNewRss()
    {
        $this->actingAs(factory(User::class)->create());
        $rss_feed = factory(RssFeed::class)->make();
        $this->post('/rss_feeds/create', $rss_feed->toArray());
        $this->assertEquals(1, RssFeed::all()->count());
    }

    public function testNonAuthenticatedUserCanNotCreateRss()
    {
        $rss_feed = factory(RssFeed::class)->make();
        $this->post('/rss_feeds/create', $rss_feed->toArray())
            ->assertRedirect('/login');
    }

    public function testNewRssRequiresUrl()
    {

        $this->actingAs(factory(User::class)->create());
        $rss_feed = factory(RssFeed::class)->make(['url' => null]);
        $this->post('/rss_feeds/create', $rss_feed->toArray())
            ->assertSessionHasErrors('url');
    }

    public function testAuthenticatedUserCanUpdateRss()
    {
        $this->actingAs(factory(User::class)->create());
        $rss_feed      = factory(RssFeed::class)->create(['user_id' => Auth::id(), 'url' => 'http://newurl.com']);
        $rss_feed->url = 'http://updatedurl.com';
        $this->put('/rss_feeds/' . $rss_feed->id, $rss_feed->toArray());
        $this->assertDatabaseHas('rss_feeds', ['id' => $rss_feed->id, 'url' => 'http://updatedurl.com']);
    }

    public function testUnauthenticatedUserCanNotUpdateRss()
    {
        $this->actingAs(factory(User::class)->create());
        $rss_feed      = factory(RssFeed::class)->create(['url' => 'http://newurl.com']);
        $rss_feed->url = 'http://updatedurl.com';
        $response      = $this->put('/rss_feeds/' . $rss_feed->id, $rss_feed->toArray());
        $response->assertStatus(403);
    }

    public function testAuthenticatedUserCanDeleteRss()
    {

        $this->actingAs(factory(User::class)->create());
        $rss_feed = factory(RssFeed::class)->create(['user_id' => Auth::id()]);
        $this->delete('/rss_feeds/' . $rss_feed->id);
        $this->assertDatabaseMissing('rss_feeds', ['id' => $rss_feed->id]);
    }

    public function testUnauthenticatedUserCanNotDeleteRss()
    {
        $this->actingAs(factory(User::class)->create());
        $rss_feed = factory(RssFeed::class)->create();
        $response = $this->delete('/rss_feeds/' . $rss_feed->id);
        $response->assertStatus(403);
    }

}
