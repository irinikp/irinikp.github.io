<?php


namespace Tests\Feature;


use App\RssFeed;
use App\User;
use Illuminate\Foundation\Testing\DatabaseMigrations;
use Illuminate\Support\Facades\Auth;
use Tests\TestCase;

class SqlInjectionTest extends TestCase
{
    use DatabaseMigrations;

    public function testSqlInjectionAEqualsAOrOnCreate()
    {
        $this->actingAs(factory(User::class)->create());
        $rss_feed = factory(RssFeed::class)->make(['url' => ' or \'a\'=\'a \'or']);
        $this->post('/rss_feeds/create', $rss_feed->toArray());
        $this->assertDatabaseMissing('rss_feeds', ['url' => ' or \'a\'=\'a \'or']);

    }

    public function testSqlInjection1OnCreate()
    {
        $this->actingAs(factory(User::class)->create());
        $rss_feed = factory(RssFeed::class)->make(['url' => '0 OR 1=1']);
        $this->post('/rss_feeds/create', $rss_feed->toArray());
        $this->assertDatabaseMissing('rss_feeds', ['url' => '0 OR 1=1']);
    }

    public function testSqlInjectionXSSOnCreate()
    {
        $this->actingAs(factory(User::class)->create());
        $rss_feed = factory(RssFeed::class)->make(['id'=>1,'url' => 'https://example.com/news?q=<script>alert(\'attacked\')</script>']);
        $this->post('/rss_feeds/create', $rss_feed->toArray());
        $this->assertDatabaseMissing('rss_feeds', ['url' => 'https://example.com/news?q=<script>alert(\'attacked\')</script>']);
    }

    public function testSqlInjectionAEqualsAOrOnUpdate()
    {
        $this->actingAs(factory(User::class)->create());
        $rss_feed      = factory(RssFeed::class)->create(['user_id' => Auth::id(), 'url' => 'http://newurl.com']);
        $rss_feed->url = ' or \'a\'=\'a \'or';
        $this->put('/rss_feeds/' . $rss_feed->id, $rss_feed->toArray());
        $this->assertDatabaseMissing('rss_feeds', ['id' => $rss_feed->id, 'url' => ' or \'a\'=\'a \'or']);
    }

    public function testSqlInjection1OnUpdate()
    {
        $this->actingAs(factory(User::class)->create());
        $rss_feed      = factory(RssFeed::class)->create(['user_id' => Auth::id(), 'url' => 'http://newurl.com']);
        $rss_feed->url = '0 OR 1=1';
        $this->put('/rss_feeds/' . $rss_feed->id, $rss_feed->toArray());
        $this->assertDatabaseMissing('rss_feeds', ['url' => '0 OR 1=1']);

    }

    public function testSqlInjectionXSSOnUpdate()
    {
        $this->actingAs(factory(User::class)->create());
        $rss_feed      = factory(RssFeed::class)->create(['user_id' => Auth::id(), 'url' => 'http://newurl.com']);
        $rss_feed->url = 'https://example.com/news?q=<script>alert(\'attacked\')</script>';
        $this->put('/rss_feeds/' . $rss_feed->id, $rss_feed->toArray());
        $this->assertDatabaseMissing('rss_feeds', ['url' => 'https://example.com/news?q=<script>alert(\'attacked\')</script>']);
    }
}