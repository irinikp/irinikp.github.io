<?php

namespace Tests\Unit;

use App\FeedArticle;
use App\Http\Controllers\RssFeedsController;
use App\RssFeed;
use App\Services\FeedReader;
use Illuminate\Foundation\Testing\DatabaseMigrations;
use Mockery;
use Tests\TestCase;

class FeedReadingTest extends TestCase
{
    use DatabaseMigrations;


    public function testReadSimpleMockFeed()
    {
        $service = Mockery::mock(FeedReader::class);

        $rss_feeds = [
            new FeedArticle('Gavin Williamson sacking: Former defence secretary denies Huawei leak', 'https://irinikp.com')
        ];
        $rss_feed  = factory(RssFeed::class)->create();
        $service->shouldReceive('read')->once()->withArgs([$rss_feed->url])->andReturn($rss_feeds);
        $response = (new RssFeedsController($service))->show($rss_feed);
        $this->assertContains('Gavin Williamson sacking: Former defence secretary denies Huawei leak', $response->render());
    }


}