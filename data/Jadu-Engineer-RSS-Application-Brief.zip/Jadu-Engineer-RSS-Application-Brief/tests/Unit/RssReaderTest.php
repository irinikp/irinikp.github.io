<?php

namespace Tests\Unit;

use App\FeedArticle;
use App\Services\FeedReader;
use App\Services\XmlRssParser;
use Tests\TestCase;

class RssReaderTest extends TestCase
{

    public function testFeedReader()
    {
        $reader = new FeedReader(new XmlRssParser());
        $feeds  = $reader->read('https://cretan.dev/feed.xml');
        $this->assertGreaterThan(0, sizeof($feeds));
        $this->assertInstanceOf(FeedArticle::class, $feeds[0]);
        $this->assertEquals('Putting the D&D in TDD', $feeds[0]->getTitle());
        $this->assertEquals('https://cretan.dev/events/dnd-tdd/', $feeds[0]->getUrl());
    }

    public function testNonRssFeedReader()
    {
        $reader = new FeedReader(new XmlRssParser());
        $feeds  = $reader->read('https://this_is_not_an_rss_feed');
        $this->assertNull($feeds);
    }
}
