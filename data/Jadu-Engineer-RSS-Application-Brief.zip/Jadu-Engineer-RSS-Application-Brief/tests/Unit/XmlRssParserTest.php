<?php


namespace Tests\Unit;

use App\Services\XmlRssParser;
use DOMDocument;
use ErrorException;
use Illuminate\Support\Facades\File;
use Tests\TestCase;

class XmlRssParserTest extends TestCase
{

    public function testGetDataFromSafeFile()
    {
        $dom = new DOMDocument();
        $dom->loadXML(File::get(base_path('tests/data/data_typical_rss.xml')));
        $rss_parser = new XmlRssParser();
        $feeds       = $rss_parser->separateFeedIntoArticles($dom);
        $this->assertNotEmpty($feeds);
        foreach ($feeds as $article) {
            $this->assertNotEquals('', $article->getTitle());
            $this->assertNotEquals('', $article->getUrl());
        }
    }

    public function testGetNoTitleDataFromSafeFile()
    {
        $dom = new DOMDocument();
        $dom->loadXML(File::get(base_path('tests/data/data_no_title_rss.xml')));
        $rss_parser = new XmlRssParser();
        $feeds       = $rss_parser->separateFeedIntoArticles($dom);
        foreach ($feeds as $article) {
            $this->assertEquals('', $article->getTitle());
            $this->assertNotEquals('', $article->getUrl());
        }
    }

    public function testGetNoUrlDataFromSafeFile()
    {
        $dom = new DOMDocument();
        $dom->loadXML(File::get(base_path('tests/data/data_no_url_rss.xml')));
        $rss_parser = new XmlRssParser();
        $feeds       = $rss_parser->separateFeedIntoArticles($dom);
        foreach ($feeds as $article) {
            $this->assertNotEquals('', $article->getTitle());
            $this->assertEquals('', $article->getUrl());
        }
    }

    public function testFilterOutDangerousXmlFromUnSafeFile()
    {
        $dom = new DOMDocument();
        $dom->loadXML(File::get(base_path('tests/data/data_xxe_vulnerability.xml')));
        $rss_parser = new XmlRssParser();
        $feeds       = $rss_parser->separateFeedIntoArticles($dom);
        $this->assertEmpty($feeds);
    }

    public function testReadRssWithWrongFormattedItemTag()
    {
        $dom = new DOMDocument();
        $dom->loadXML(File::get(base_path('tests/data/data_no_items_rss.xml')));
        $rss_parser = new XmlRssParser();
        $feeds       = $rss_parser->separateFeedIntoArticles($dom);
        $this->assertEmpty($feeds);
    }

    public function testXmlParserForXMLInjection()
    {
        $dom = new DOMDocument();
        $dom->loadXML(File::get(base_path('tests/data/data_xml_injection1.xml')));
        $rss_parser = new XmlRssParser();
        $feeds       = $rss_parser->separateFeedIntoArticles($dom);
        $this->assertNotEquals('alert(\'xss\')', $feeds[0]->getTitle());
    }

    public function testXmlParserForBillionLaughs()
    {
        $dom = new DOMDocument();
        $this->expectException(ErrorException::class);
        $dom->loadXML(File::get(base_path('tests/data/data_billion_laughs.xml')));
    }

}