# Time Analysis

Below you can see the percentage of time spent on each step:

1. **5%** Setting up the environment, database and deciding on how my next steps will be
2. **10%** Building a basic CRUD: Writing a test, implementing the Controller's function. 
    The time spent on View was minimum at this point. 
3. **10%** Updating the view (writing a browser's test and updating the View accordingly)
4. **2%** Adding specific items on database seeding, for testing purposes 
5. **3%** Adding an extra policy about user deleting an rss, that had been omitted on step 2
6. **10%** Adding new feature: show title and url of each feed's article
7. **20%** Asserting that all project is safe against attacks (specifically XXE Attack and SQL injection)
8. **10%** Reconfiguring rss reader in cases of broken feed
9. **10%** Writing readme, instructions and time markdown files
10. **20%** Refactoring after every passing test
